
import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Copy, RefreshCw, Trash2 } from 'lucide-react';
import axios from 'axios';

export default function App() {
  const [email, setEmail] = useState('');
  const [token, setToken] = useState('');
  const [messages, setMessages] = useState([]);
  const [selectedMsg, setSelectedMsg] = useState(null);

  useEffect(() => {
    generateNewEmail();
  }, []);

  useEffect(() => {
    if (token) {
      const interval = setInterval(fetchMessages, 10000);
      return () => clearInterval(interval);
    }
  }, [token]);

  const generateNewEmail = async () => {
    const domainRes = await axios.get("https://api.mail.tm/domains");
    const domain = domainRes.data['hydra:member'][0].domain;
    const username = Math.random().toString(36).substring(2, 11);
    const address = `${username}@${domain}`;
    const pass = username + 'Pass';

    await axios.post('https://api.mail.tm/accounts', { address, password: pass });
    const tokenRes = await axios.post('https://api.mail.tm/token', { address, password: pass });

    setEmail(address);
    setToken(tokenRes.data.token);
    localStorage.setItem('jwt', tokenRes.data.token);
  };

  const fetchMessages = async () => {
    const res = await axios.get('https://api.mail.tm/messages', {
      headers: { Authorization: `Bearer ${token}` },
    });
    setMessages(res.data['hydra:member']);
  };

  const fetchMessageDetail = async (id) => {
    const res = await axios.get(`https://api.mail.tm/messages/${id}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    setSelectedMsg(res.data);
  };

  const deleteInbox = () => {
    setEmail('');
    setMessages([]);
    setSelectedMsg(null);
    setToken('');
    localStorage.removeItem('jwt');
    generateNewEmail();
  };

  return (
    <div className="p-4 text-white bg-black min-h-screen">
      <motion.h1
        animate={{ rotate: [0, 10, -10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="text-3xl font-bold mb-4"
      >
        Burn Your Inbox. Go Ghost.
      </motion.h1>

      {email && (
        <div className="bg-gray-800 rounded-lg p-4 mt-4">
          <div className="flex items-center justify-between">
            <span className="text-xl">{email}</span>
            <div className="flex gap-2">
              <button onClick={() => navigator.clipboard.writeText(email)}><Copy size={20} /></button>
              <button onClick={generateNewEmail}><RefreshCw size={20} /></button>
              <button onClick={deleteInbox}><Trash2 size={20} /></button>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h2 className="text-xl mb-2">Inbox</h2>
              <div className="space-y-2">
                {messages.map((msg) => (
                  <div key={msg.id} className="bg-gray-700 p-2 rounded cursor-pointer hover:bg-gray-600" onClick={() => fetchMessageDetail(msg.id)}>
                    <div className="font-semibold">{msg.from?.address}</div>
                    <div>{msg.subject}</div>
                    <div className="text-sm text-gray-400">{msg.intro}</div>
                  </div>
                ))}
              </div>
            </div>
            <div>
              {selectedMsg && (
                <div className="bg-gray-700 p-4 rounded">
                  <h2 className="text-xl font-bold mb-2">{selectedMsg.subject}</h2>
                  <div className="text-sm text-gray-400 mb-2">From: {selectedMsg.from?.address}</div>
                  <div dangerouslySetInnerHTML={{ __html: selectedMsg.html?.[0] || selectedMsg.text }}></div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
